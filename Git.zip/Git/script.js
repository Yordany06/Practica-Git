document.getElementById('colorButton').addEventListener('click', function() {
    const colors = ['#ff69b4', '#dda0dd', '#ffffff', '#f4c2c2']; // Rosado, Morado, Blanco, Palo Rosa
    const currentColor = document.body.style.backgroundColor;
    let newColor = colors[Math.floor(Math.random() * colors.length)];
    while (newColor === currentColor) {
        newColor = colors[Math.floor(Math.random() * colors.length)];
    }
    document.body.style.backgroundColor = newColor;
});
